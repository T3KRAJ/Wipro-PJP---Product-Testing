# Tek Raj Joshi
# Superset ID: 1368453

distance = int(input("How far do you want to travel (in miles)?"))
if distance < 3:
    print("Ride bicycle")
elif distance < 300:
    print("Ride Motor-Cycle")
else:
    print("Ride Super-Car")