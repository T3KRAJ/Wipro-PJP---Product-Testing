num = int(input())
if num % 2 == 0:
    print("Even Number")
else:
    print("Odd Number")