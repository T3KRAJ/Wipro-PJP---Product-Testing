for i in range(23, 57):
    if i % 2 == 0:
        print(i)