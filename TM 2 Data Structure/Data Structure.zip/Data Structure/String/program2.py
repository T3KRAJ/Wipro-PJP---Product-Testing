# Tek Raj Joshi
# Superset ID: 1368453

input_string = input("Enter a string: ")
if input_string == input_string[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")