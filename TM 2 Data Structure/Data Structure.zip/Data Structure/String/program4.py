# Tek Raj Joshi
# Superset ID: 1368453

input_string = input("Enter a string: ")

if input_string[0] == 'x' and input_string[-1] == 'x':
    print(input_string[1:-1])
else:
    print(input_string)