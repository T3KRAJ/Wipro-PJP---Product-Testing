# Tek Raj Joshi
# Superset ID: 1368453

input_string = input("Enter a string: ")
res = ''
for i in range(len(input_string)):
    res += input_string[:2]
print(res)