# Tek Raj Joshi
# Superset ID: 1368453

dictionary = {i:i*i for i in range(1, 16)}
print(dictionary)