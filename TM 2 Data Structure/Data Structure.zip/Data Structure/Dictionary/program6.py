# Tek Raj Joshi
# Superset ID: 1368453

dictionary = {0: 0, 1: 1, 3: 9, 5: 25, 7: 49, 9: 81}
res = 0
for key,value in dictionary.items():
    res += value
print(res)