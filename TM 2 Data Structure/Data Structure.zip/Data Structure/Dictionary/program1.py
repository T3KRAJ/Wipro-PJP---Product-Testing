# Tek Raj Joshi
# Superset ID: 1368453

sample_dictionary = {0: 10, 1: 20}
key = int(input("Enter new key: "))
value = int(input("Enter new value: "))
sample_dictionary[key] = value
print(sample_dictionary)
