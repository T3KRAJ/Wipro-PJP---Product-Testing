# Tek Raj Joshi
# Superset ID: 1368453

dict1 = {0: 0, 1: 1, 3: 9}
dict2 = {5: 25, 7: 49, 9: 81}
dict1.update(dict2)
print(dict1)
