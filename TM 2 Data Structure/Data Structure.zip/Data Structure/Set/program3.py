# Tek Raj Joshi
# Superset ID: 1368453

set1 = set(map(int, input("Enter the space seperated integers for set1: ").split()))
set2 = set(map(int, input("Enter the space seperated integers for set2: ").split()))
print(set1.union(set2))