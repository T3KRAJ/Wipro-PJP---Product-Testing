# Tek Raj Joshi
# Superset ID: 1368453

set_of_integers = set(map(int, input("Enter the space seperated integers: ").split()))
print("Maximum: ", max(set_of_integers))
print("Minimum: ", min(set_of_integers))