# Tek Raj Joshi
# Superset ID: 1368453

array_of_integers = list(map(int, input("Enter the space seperated integers").split()))
integer_to_count = int(input("Element to count: "))
print(array_of_integers.count(integer_to_count))