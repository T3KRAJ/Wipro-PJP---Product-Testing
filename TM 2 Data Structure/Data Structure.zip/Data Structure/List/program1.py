# Tek Raj Joshi
# Superset ID: 1368453

array_of_five_integers = [2,3,5,6,9]
for i in range(len(array_of_five_integers)):
    print(array_of_five_integers[i])