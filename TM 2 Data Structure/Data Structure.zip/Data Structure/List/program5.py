# Tek Raj Joshi
# Superset ID: 1368453

array1 = list(map(int, input("Enter the space seperated integers for array 1: ").split()))
array2 = list(map(int, input("Enter the space seperated integers for array 2: ").split()))
array2 = array1 + array2
print(array2)

