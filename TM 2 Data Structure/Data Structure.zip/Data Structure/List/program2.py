# Tek Raj Joshi
# Superset ID: 1368453

array_of_integers = [2,3,5,6,9]
element_to_append = int(input('Enter the element to append'))
array_of_integers.append(element_to_append)
print(array_of_integers)