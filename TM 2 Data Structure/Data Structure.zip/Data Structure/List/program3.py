# Tek Raj Joshi
# Superset ID: 1368453

array_of_integers = [2,3,5,6,9]
reverse_of_the_list = array_of_integers[::-1]
print(reverse_of_the_list)