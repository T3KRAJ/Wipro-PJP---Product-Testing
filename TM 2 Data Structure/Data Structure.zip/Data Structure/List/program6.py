# Tek Raj Joshi
# Superset ID: 1368453

array_of_integers = list(map(int, input("Enter the space seperated integers: ").split()))
element_to_be_inserted = int(input("Enter the element to be inserted in second position"))
array_of_integers[1] = element_to_be_inserted
print(array_of_integers)