# Tek Raj Joshi
# Superset ID: 1368453

my_tuple = ('p','e','r','m','i','t')
element_to_check = input("Enter the element to check")
print(element_to_check in my_tuple)