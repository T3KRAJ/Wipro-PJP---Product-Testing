# Tek Raj Joshi
# Superset ID: 1368453

array_of_integers = list(map(int, input("Enter the space seperated integers").split()))
print(tuple(array_of_integers))
