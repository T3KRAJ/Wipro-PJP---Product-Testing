# Tek Raj Joshi
# Superset ID: 1368453

tuple_of_integers = tuple(map(int, input("Enter the space seperated integers").split()))
elemet_to_check_for_index = int(input("Enter the element to check for its index"))
print(tuple_of_integers.index(elemet_to_check_for_index))