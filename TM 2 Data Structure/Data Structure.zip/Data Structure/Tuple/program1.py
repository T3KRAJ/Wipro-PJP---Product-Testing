# Tek Raj Joshi
# Superset ID: 1368453

my_tuple = ('p','e','r','m','i','t')
print("4th element from first: ", my_tuple[3])
print("4th element from last: ", my_tuple[-4])