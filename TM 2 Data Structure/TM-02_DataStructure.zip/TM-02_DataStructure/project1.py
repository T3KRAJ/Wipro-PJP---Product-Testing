# Tek Raj Joshi
# Superset ID: 1368453

people_dict = {
    "kamal": "loves playing chess",
    "Raju": "is afraid of swimming",
    "Ritesh": "wakes up early in the morning",
}
print(people_dict)

people_dict = {
    "kamal": "is always late",
    "Raju": "is afraid of swimming",
    "Sheela": "doesnot know how to ride bicycle",
    "Ritesh": "wakes up early in the morning",
}
print(people_dict)