# Tek Raj Joshi
# Superset ID: 1368453

import string


string_of_n_words = input("Enter the string: ")
print(string_of_n_words.count("Alex") )