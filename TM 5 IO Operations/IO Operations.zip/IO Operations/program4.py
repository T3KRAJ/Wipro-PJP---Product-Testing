# Tek Raj Joshi
# Superset ID: 1368453

with open('filename.txt', mode='r', encoding = 'utf-8') as f:
    print(f.readlines())