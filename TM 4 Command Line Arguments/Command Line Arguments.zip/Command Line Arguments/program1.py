# Tek Raj Joshi
# Superset ID: 1368453

import sys

x=int(sys.argv[1])
y=int(sys.argv[2])
sum= x + y
print("The addition is :",sum)