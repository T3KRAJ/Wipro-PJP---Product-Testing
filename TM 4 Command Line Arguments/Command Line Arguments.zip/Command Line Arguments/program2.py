# Tek Raj Joshi
# Superset ID: 1368453

import sys

print("File Name is: ",sys.argv[0])
print(sys.argv[1])
