# Tek Raj Joshi
# Superset ID: 1368453

import sys

nums = []

for i in range(10):
    nums.append(int(sys.argv[i+1]))
print("Total sum is :",sum(nums))