# Tek Raj Joshi
# Superset ID: 1368453

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

try:
    print("Result is: ", num1/num2)
except Exception as e:
        print("Oops!", e, "occurred.")
