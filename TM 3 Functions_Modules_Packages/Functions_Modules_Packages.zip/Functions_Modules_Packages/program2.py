# Tek Raj Joshi
# Superset ID: 1368453


def get_reverse(str):
    return str[::-1]

input_string = input("Enter the string: ")
print(get_reverse(input_string))