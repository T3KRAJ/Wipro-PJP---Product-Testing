# Tek Raj Joshi
# Superset ID: 1368453

def get_sum(integers):
    return sum(integers)

array_of_integers = list(map(int, input("Enter the space seperated integers: ").split()))
print(get_sum(array_of_integers))