// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
echo $TERM
echo $SHELL
echo $BASH-VERSION
echo $HOSTNAME
echo $CDPATH