// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
grep linuxusr1 /etc/passwd ; date