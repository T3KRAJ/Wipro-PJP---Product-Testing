// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
cd store
for file in *; do mv -- "$file" "$file.txt"; done