// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
date
date|awk '{print $1}'
date "+%A"