// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
mkdir store
cd store
for i in {1..200}; do touch myfile${i}; done