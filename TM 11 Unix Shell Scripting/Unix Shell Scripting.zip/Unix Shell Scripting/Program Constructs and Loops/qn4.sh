// Tek Raj Joshi
// Superset ID: 1368453

#!/bin/sh
read -p "Enter a number: " num
count=1
while
while [ $count -le 10 ]
do
echo " $num x $count = $(( num * count )) "
count=$((count + 1))
done