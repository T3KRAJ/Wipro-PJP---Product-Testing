// Tek Raj Joshi
// Superset ID: 1368453

using System;  
  public class Program1  
   {  
     public static void Main(string[] args)  
      {  
       int  num1=7, num2=8;            
       Console.WriteLine("Before swap num1 = "+ num1 + " num2= " + num2);    
       num1=num1*num2;       
       num2=num1/num2;       
       num1=num1/num2;    
       Console.Write("After swap num1 = "+ num1 +" num2 = " + num2);       
     }  
  }