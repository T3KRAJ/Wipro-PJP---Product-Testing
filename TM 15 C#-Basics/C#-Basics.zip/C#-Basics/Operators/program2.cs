// Tek Raj Joshi
// Superset ID: 1368453

using System;
public class Program2
{
    public static void Main()
    {
        int num1, rem1;
        Console.Write("Input Number One : ");
        num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input Number Two : ");
        num2 = Convert.ToInt32(Console.ReadLine());
        num2 = +num1;
        num1 = +num2;
        Console.WriteLine("Num1 is: ", num1);
        Console.WriteLine("Num2 is: ", num2);
    }
}