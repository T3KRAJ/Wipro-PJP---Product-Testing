// Tek Raj Joshi
// Superset ID: 1368453

using System;  
public class Program3  
{  
    public static void Main()  
    {
    int num;
    Console.Write("Input an integer : ");
    num1= Convert.ToInt32(Console.ReadLine()); 
    if (num % 2 == 0)
 Console.WriteLine("{0} is an even integer.\n",num1);
    else
 Console.WriteLine("{0} is an odd integer.\n",num1);
}
}