// Tek Raj Joshi
// Superset ID: 1368453

using System;
  public class Program4 
   {  
     public static async void Main(string[] args)  
      {  
       int  num;      
       Console.Write("Enter the Number= ");      
       n= int.Parse(Console.ReadLine());     
        for (int i = 1; i <= 10; i++) {
            Console.Write(num + "x" + i + "= " + num*i + "\n");      
        }

      }  
  }