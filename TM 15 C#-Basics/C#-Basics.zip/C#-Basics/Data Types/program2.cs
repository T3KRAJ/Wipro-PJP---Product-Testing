// Tek Raj Joshi
// Superset ID: 1368453

using System;  
  
namespace Program2  
{  
    class Program2
    {  
        static void Main(string[] args)  
        {  
            int NumberOne, NumberTwo;  
            NumberOne = Convert.ToInt32(Console.ReadLine());  
            NumberTwo = Convert.ToInt32(Console.ReadLine());  
            int Result;
            Console.WriteLine("Given Input: Number One =" + NumberOne + "Number Two =" + NumberTwo);  
            Result = (x + y);
            Console.WriteLine("Addition of" + NumberOne + "and" + NumberTwo + "is: " + Result);
            Result = (x - y);
            Console.WriteLine("Subtraction of" + NumberOne + "and" + NumberTwo + "is: " + Result);
            Result = (x * y);
            Console.WriteLine("Multiplication of" + NumberOne + "and" + NumberTwo + "is: "+ Result);
            Result = (x / y);
            Console.WriteLine("Division of" + NumberOne + "and" + NumberTwo + "is: " + Result);
            Result = (x % y);
            Console.WriteLine( NumberOne + "mod" + NumberTwo + "is: " + Result);
        }  
    }  
} 