// Tek Raj Joshi
// Superset ID: 1368453

using System; 
class Program1 { 
    public static void Main() 
    {
        int[] arr = new int[] {2, 4, 6, 8, 10}; 
        foreach(int value in arr) 
        { 
            Console.Write(value + " "); 
        } 

    } 
} 